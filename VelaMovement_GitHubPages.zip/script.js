let cart=0;
const imgs=[
'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab',
'https://images.unsplash.com/photo-1503341504253-dff4815485f1',
'https://images.unsplash.com/photo-1483985988355-763728e1935b',
'https://images.unsplash.com/photo-1512436991641-6745cdb1723f'];
function gallery(){return `<div class="gallery">${imgs.map(i=>`<img src="${i}">`).join('')}</div>`}
function addCart(){cart++;document.getElementById('cartCount').textContent=cart;alert('Harbor Sweatshirt added to cart');}
function showPage(page){const c=document.getElementById('content');
if(page==='ethics') c.innerHTML=`<div class='section'><h1>Ethics & Founder Story</h1><p>Vela Movement was created to blend comfort, accessibility and coastal style.</p><h2>Founder Story</h2><p>Built around fewer, better essentials.</p></div>`;
else if(page==='product') c.innerHTML=`<div class='section'><h1>Harbor Sweatshirt</h1><h2>$78</h2><label>Color</label><select><option>Silver Mist</option><option>Coastal Blue</option><option>Sand Beige</option></select><br><br><label>Size</label><select><option>XS</option><option>S</option><option>M</option><option>L</option></select><br><br><button class='btn' onclick='addCart()'>Add to Cart</button>${gallery()}</div>`;
else c.innerHTML=`<section class='hero'><div><h1>Move Like the Tide.</h1><p>Premium coastal apparel inspired by ocean air and everyday movement.</p><button class='btn' onclick="showPage('product')">Shop Harbor Sweatshirt</button></div><img src='${imgs[0]}'></section><div class='section'><h2>Social Gallery</h2>${gallery()}</div>`;
}
showPage('home');
